const path = require('path');
const fs = require('fs');
const multer = require('multer');

const uploadsRoot = path.join(__dirname, '..', 'public', 'uploads');

const DOCUMENT_EXTENSIONS = ['.pdf', '.doc', '.docx', '.hwp', '.xls', '.xlsx', '.ppt', '.pptx'];

function subDirFor(fieldname) {
  if (fieldname === 'video') return 'videos';
  if (fieldname === 'file') return 'files';
  return 'images';
}

const storage = multer.diskStorage({
  destination(req, file, cb) {
    const dir = path.join(uploadsRoot, subDirFor(file.fieldname));
    fs.mkdirSync(dir, { recursive: true });
    cb(null, dir);
  },
  filename(req, file, cb) {
    const ext = path.extname(file.originalname).toLowerCase();
    const unique = `${Date.now()}-${Math.round(Math.random() * 1e9)}${ext}`;
    cb(null, unique);
  },
});

function fileFilter(req, file, cb) {
  if (file.fieldname === 'image' && file.mimetype.startsWith('image/')) {
    return cb(null, true);
  }
  if (file.fieldname === 'video' && file.mimetype.startsWith('video/')) {
    return cb(null, true);
  }
  if (file.fieldname === 'file' && DOCUMENT_EXTENSIONS.includes(path.extname(file.originalname).toLowerCase())) {
    return cb(null, true);
  }
  cb(new Error('허용되지 않는 파일 형식입니다.'));
}

const upload = multer({
  storage,
  fileFilter,
  limits: { fileSize: 200 * 1024 * 1024 }, // 200MB
});

module.exports = upload;
