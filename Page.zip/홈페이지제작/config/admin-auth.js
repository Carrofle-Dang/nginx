// 관리자 로그인 계정. 실제 운영 전 반드시 변경하세요.
// 환경변수(ADMIN_USERNAME, ADMIN_PASSWORD)로 덮어쓸 수 있습니다.
module.exports = {
  username: process.env.ADMIN_USERNAME || 'admin',
  password: process.env.ADMIN_PASSWORD || 'lifedesign2025!',
};
