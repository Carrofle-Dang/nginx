document.addEventListener('DOMContentLoaded', () => {
  // Category filter (Academy)
  const filterButtons = document.querySelectorAll('[data-filter]');
  const filterItems = document.querySelectorAll('[data-category]');
  if (filterButtons.length && filterItems.length) {
    filterButtons.forEach((btn) => {
      btn.addEventListener('click', () => {
        filterButtons.forEach((b) => b.classList.remove('active'));
        btn.classList.add('active');
        const target = btn.getAttribute('data-filter');
        filterItems.forEach((item) => {
          const show = target === 'all' || item.getAttribute('data-category') === target;
          item.closest('.filter-col').style.display = show ? '' : 'none';
        });
      });
    });
  }

  // Horizontal scroll carousels
  document.querySelectorAll('[data-carousel]').forEach((wrapper) => {
    const track = wrapper.querySelector('.scroll-carousel');
    const prev = wrapper.querySelector('[data-scroll="prev"]');
    const next = wrapper.querySelector('[data-scroll="next"]');
    if (!track) return;
    const scrollAmount = 280;
    if (prev) prev.addEventListener('click', () => track.scrollBy({ left: -scrollAmount, behavior: 'smooth' }));
    if (next) next.addEventListener('click', () => track.scrollBy({ left: scrollAmount, behavior: 'smooth' }));
  });

  // 팝업 형태의 제출 폼(상담 신청/문의, 후기·Q&A 작성) 공통 처리
  function setupPopupForm({ modalId, formId, formWrapId, successId, errorId, endpoint, requiredFields, requiredMessage }) {
    const modalEl = document.getElementById(modalId);
    if (!modalEl) return;

    const form = document.getElementById(formId);
    const formWrap = document.getElementById(formWrapId);
    const successEl = document.getElementById(successId);
    const errorEl = document.getElementById(errorId);

    modalEl.addEventListener('hidden.bs.modal', () => {
      form.reset();
      formWrap.classList.remove('d-none');
      successEl.classList.add('d-none');
      errorEl.classList.add('d-none');
    });

    form.addEventListener('submit', async (e) => {
      e.preventDefault();
      errorEl.classList.add('d-none');

      const data = Object.fromEntries(new FormData(form).entries());
      const missing = requiredFields.some((field) => !data[field] || !data[field].trim());
      if (missing) {
        errorEl.textContent = requiredMessage;
        errorEl.classList.remove('d-none');
        return;
      }

      const submitBtn = form.querySelector('button[type="submit"]');
      submitBtn.disabled = true;

      try {
        const res = await fetch(endpoint, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(data),
        });
        const json = await res.json();
        if (json.ok) {
          formWrap.classList.add('d-none');
          successEl.classList.remove('d-none');
        } else {
          errorEl.textContent = json.error || '제출 중 오류가 발생했습니다.';
          errorEl.classList.remove('d-none');
        }
      } catch (err) {
        errorEl.textContent = '제출 중 오류가 발생했습니다. 잠시 후 다시 시도해주세요.';
        errorEl.classList.remove('d-none');
      } finally {
        submitBtn.disabled = false;
      }
    });

    return modalEl;
  }

  // 상담 신청/문의 팝업
  const consultModalEl = setupPopupForm({
    modalId: 'consultationModal',
    formId: 'consultForm',
    formWrapId: 'consultFormWrap',
    successId: 'consultSuccess',
    errorId: 'consultError',
    endpoint: '/consultations',
    requiredFields: ['name', 'phone', 'message'],
    requiredMessage: '이름, 전화번호, 상담 내용을 모두 입력해주세요.',
  });

  if (consultModalEl) {
    const sourceInput = document.getElementById('consultSource');
    const titleEl = document.getElementById('consultModalTitle');
    consultModalEl.addEventListener('show.bs.modal', (event) => {
      const trigger = event.relatedTarget;
      const source = trigger && trigger.getAttribute('data-source') ? trigger.getAttribute('data-source') : document.title;
      sourceInput.value = source;
      titleEl.textContent = (trigger && trigger.textContent.trim()) || '상담 신청';
    });
  }

  // 후기·Q&A 작성 팝업
  setupPopupForm({
    modalId: 'writePostModal',
    formId: 'writePostForm',
    formWrapId: 'writePostFormWrap',
    successId: 'writePostSuccess',
    errorId: 'writePostError',
    endpoint: '/community/posts',
    requiredFields: ['category', 'author', 'title', 'excerpt'],
    requiredMessage: '구분, 이름, 제목, 내용을 모두 입력해주세요.',
  });
});
