const path = require('path');
const { DatabaseSync } = require('node:sqlite');
const seed = require('./seed');

const dbPath = path.join(__dirname, 'lifedesign.db');
const db = new DatabaseSync(dbPath);
db.exec('PRAGMA journal_mode = WAL');

function createSchema() {
  db.exec(`
    CREATE TABLE IF NOT EXISTS pages (
      slug TEXT PRIMARY KEY,
      title TEXT,
      subtitle TEXT,
      description TEXT,
      hero_image TEXT
    );

    CREATE TABLE IF NOT EXISTS features (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      page TEXT NOT NULL,
      icon TEXT,
      title TEXT,
      description TEXT,
      sort_order INTEGER DEFAULT 0
    );

    CREATE TABLE IF NOT EXISTS courses (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      category TEXT,
      category_label TEXT,
      title TEXT,
      description TEXT,
      duration TEXT,
      level TEXT,
      format TEXT,
      image_path TEXT,
      video_path TEXT,
      sort_order INTEGER DEFAULT 0
    );

    CREATE TABLE IF NOT EXISTS diagnostics (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      title TEXT,
      description TEXT,
      time_tag TEXT,
      icon TEXT,
      sort_order INTEGER DEFAULT 0
    );

    CREATE TABLE IF NOT EXISTS diagnostic_questions (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      diagnostic_id INTEGER NOT NULL,
      question TEXT,
      sort_order INTEGER DEFAULT 0
    );

    CREATE TABLE IF NOT EXISTS diagnostic_results (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      diagnostic_id INTEGER NOT NULL,
      tier TEXT NOT NULL,
      title TEXT,
      description TEXT
    );

    CREATE TABLE IF NOT EXISTS workbooks (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      num TEXT,
      title TEXT,
      subtitle TEXT,
      icon TEXT,
      color TEXT,
      file_path TEXT,
      sort_order INTEGER DEFAULT 0
    );

    CREATE TABLE IF NOT EXISTS missions (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      num TEXT,
      title TEXT,
      sort_order INTEGER DEFAULT 0
    );

    CREATE TABLE IF NOT EXISTS resources (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      title TEXT,
      file_type TEXT,
      sort_order INTEGER DEFAULT 0
    );

    CREATE TABLE IF NOT EXISTS values_list (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      num TEXT,
      title TEXT,
      description TEXT,
      sort_order INTEGER DEFAULT 0
    );

    CREATE TABLE IF NOT EXISTS story_timeline (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      year TEXT,
      description TEXT,
      sort_order INTEGER DEFAULT 0
    );

    CREATE TABLE IF NOT EXISTS representative (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      name TEXT,
      role TEXT,
      bio TEXT,
      credentials TEXT,
      quote TEXT
    );

    CREATE TABLE IF NOT EXISTS services (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      category TEXT,
      title TEXT,
      description TEXT,
      icon TEXT,
      sort_order INTEGER DEFAULT 0
    );

    CREATE TABLE IF NOT EXISTS process_steps (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      num TEXT,
      title TEXT,
      description TEXT,
      sort_order INTEGER DEFAULT 0
    );

    CREATE TABLE IF NOT EXISTS community_posts (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      category TEXT,
      title TEXT,
      excerpt TEXT,
      post_date TEXT,
      author TEXT,
      status TEXT DEFAULT 'published',
      sort_order INTEGER DEFAULT 0
    );

    CREATE TABLE IF NOT EXISTS consultations (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      name TEXT,
      phone TEXT,
      message TEXT,
      source TEXT,
      status TEXT DEFAULT 'new',
      created_at TEXT DEFAULT (datetime('now', 'localtime'))
    );
  `);
}

function isEmpty() {
  const row = db.prepare('SELECT COUNT(*) AS cnt FROM pages').get();
  return row.cnt === 0;
}

function ensureColumn(table, column, definition) {
  const columns = db.prepare(`PRAGMA table_info(${table})`).all();
  const exists = columns.some((c) => c.name === column);
  if (!exists) {
    db.exec(`ALTER TABLE ${table} ADD COLUMN ${column} ${definition}`);
  }
}

createSchema();
ensureColumn('pages', 'hero_image', 'TEXT');
ensureColumn('pages', 'video_path', 'TEXT');
ensureColumn('workbooks', 'file_path', 'TEXT');
ensureColumn('community_posts', 'author', 'TEXT');
ensureColumn('community_posts', 'status', "TEXT DEFAULT 'published'");
if (isEmpty()) {
  seed(db);
} else {
  seed.backfillDiagnosticContent(db);
}

module.exports = db;
