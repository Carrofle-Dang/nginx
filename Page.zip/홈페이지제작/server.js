const express = require('express');
const path = require('path');
const session = require('express-session');
const routes = require('./routes');
const adminRoutes = require('./routes/admin');
const consultationRoutes = require('./routes/consultations');
const diagnosticRoutes = require('./routes/diagnostics');

const app = express();
const PORT = process.env.PORT || 3000;

app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));

app.use(express.static(path.join(__dirname, 'public')));
app.use(express.urlencoded({ extended: true }));
app.use(express.json());

app.use(
  session({
    secret: process.env.SESSION_SECRET || 'life-design-company-admin-secret',
    resave: false,
    saveUninitialized: false,
    cookie: { maxAge: 1000 * 60 * 60 * 8 }, // 8시간
  })
);

app.use('/admin', adminRoutes);
app.use('/consultations', consultationRoutes);
app.use('/lab/diagnostics', diagnosticRoutes);
app.use('/', routes);

app.use((req, res) => {
  res.status(404).render('404', {
    active: '',
    page: { title: '페이지를 찾을 수 없습니다', description: '요청하신 페이지를 찾을 수 없습니다.' },
  });
});

app.listen(PORT, () => {
  console.log(`Life Design Company server running: http://localhost:${PORT}`);
});
