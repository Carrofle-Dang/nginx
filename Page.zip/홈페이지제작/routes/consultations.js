const express = require('express');
const db = require('../db/database');

const router = express.Router();

router.post('/', (req, res) => {
  const body = req.body || {};
  const name = String(body.name || '').trim();
  const phone = String(body.phone || '').trim();
  const message = String(body.message || '').trim();
  const source = String(body.source || '').trim().slice(0, 100);

  if (!name || !phone || !message) {
    return res.status(400).json({ ok: false, error: '이름, 전화번호, 상담 내용을 모두 입력해주세요.' });
  }
  if (name.length > 50 || phone.length > 30 || message.length > 2000) {
    return res.status(400).json({ ok: false, error: '입력 길이를 확인해주세요.' });
  }

  db.prepare(
    `INSERT INTO consultations (name, phone, message, source, status) VALUES (?, ?, ?, ?, 'new')`
  ).run(name, phone, message, source);

  res.json({ ok: true });
});

module.exports = router;
