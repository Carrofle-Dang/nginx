const express = require('express');
const db = require('../db/database');

const router = express.Router();

function getDiagnostic(id) {
  return db.prepare('SELECT * FROM diagnostics WHERE id = ?').get(id);
}

function getQuestions(diagnosticId) {
  return db.prepare('SELECT * FROM diagnostic_questions WHERE diagnostic_id = ? ORDER BY sort_order').all(diagnosticId);
}

router.get('/', (req, res) => {
  const diagnostics = db.prepare('SELECT * FROM diagnostics ORDER BY sort_order').all();
  res.render('lab-diagnostics', {
    active: 'lab',
    page: { title: '진단 도구', description: '지금 내 상황을 점검하고 우선순위를 확인해보세요.' },
    diagnostics,
  });
});

router.get('/:id', (req, res) => {
  const diagnostic = getDiagnostic(req.params.id);
  if (!diagnostic) return res.redirect('/lab');
  const questions = getQuestions(diagnostic.id);
  res.render('diagnostic', {
    active: 'lab',
    page: { title: diagnostic.title, description: diagnostic.description, hero_image: null },
    diagnostic,
    questions,
    result: null,
  });
});

router.post('/:id', (req, res) => {
  const diagnostic = getDiagnostic(req.params.id);
  if (!diagnostic) return res.redirect('/lab');
  const questions = getQuestions(diagnostic.id);

  let checked = req.body.answers || [];
  if (!Array.isArray(checked)) checked = [checked];
  checked = checked.map(String);

  const total = questions.length;
  const checkedCount = questions.filter((q) => checked.includes(String(q.id))).length;
  const percent = total > 0 ? Math.round((checkedCount / total) * 100) : 0;

  let tier = 'low';
  if (percent >= 70) tier = 'high';
  else if (percent >= 40) tier = 'mid';

  const tierRow = db
    .prepare('SELECT * FROM diagnostic_results WHERE diagnostic_id = ? AND tier = ?')
    .get(diagnostic.id, tier);

  res.render('diagnostic', {
    active: 'lab',
    page: { title: diagnostic.title, description: diagnostic.description, hero_image: null },
    diagnostic,
    questions,
    result: {
      checkedCount,
      total,
      percent,
      tier,
      title: tierRow ? tierRow.title : '',
      description: tierRow ? tierRow.description : '',
      checkedIds: checked,
    },
  });
});

module.exports = router;
