const express = require('express');
const db = require('../db/database');

const router = express.Router();

function getPage(slug) {
  return db.prepare('SELECT * FROM pages WHERE slug = ?').get(slug);
}

const COURSE_CATEGORIES = [
  { key: 'all', label: '전체' },
  { key: 'prep', label: '예비·신혼' },
  { key: 'family', label: '가정·자녀' },
  { key: 'finance', label: '재무·자산' },
  { key: 'retire', label: '은퇴·노후' },
  { key: 'inherit', label: '상속·증여' },
];

router.get('/', (req, res) => {
  const page = getPage('home');
  const courses = db.prepare('SELECT * FROM courses ORDER BY sort_order').all();
  const diagnostics = db.prepare('SELECT * FROM diagnostics ORDER BY sort_order LIMIT 4').all();
  const services = db.prepare('SELECT * FROM services ORDER BY sort_order').all();
  res.render('index', { active: 'home', page, courses, diagnostics, services });
});

router.get('/academy', (req, res) => {
  const page = getPage('academy');
  const features = db.prepare('SELECT * FROM features WHERE page = ? ORDER BY sort_order').all('academy');
  const courses = db.prepare('SELECT * FROM courses ORDER BY sort_order').all();
  const differentiators = db.prepare('SELECT * FROM features WHERE page = ? ORDER BY sort_order').all('academy-diff');
  res.render('academy', { active: 'academy', page, features, courses, differentiators, categories: COURSE_CATEGORIES });
});

router.get('/academy/courses', (req, res) => {
  const page = getPage('academy');
  const courses = db.prepare('SELECT * FROM courses ORDER BY sort_order').all();
  res.render('academy-courses', { active: 'academy', page, courses, categories: COURSE_CATEGORIES });
});

router.get('/lab', (req, res) => {
  const page = getPage('lab');
  const features = db.prepare('SELECT * FROM features WHERE page = ? ORDER BY sort_order').all('lab');
  const diagnostics = db.prepare('SELECT * FROM diagnostics ORDER BY sort_order').all();
  const workbooks = db.prepare('SELECT * FROM workbooks ORDER BY sort_order').all();
  const missions = db.prepare('SELECT * FROM missions ORDER BY sort_order').all();
  const resources = db.prepare('SELECT * FROM resources ORDER BY sort_order').all();
  res.render('lab', { active: 'lab', page, features, diagnostics, workbooks, missions, resources });
});

router.get('/lab/workbooks', (req, res) => {
  const workbooks = db.prepare('SELECT * FROM workbooks ORDER BY sort_order').all();
  res.render('lab-workbooks', {
    active: 'lab',
    page: { title: '워크북', description: '생각을 정리하고, 계획을 세우는 단계별 워크북입니다.' },
    workbooks,
  });
});

router.get('/lab/missions', (req, res) => {
  const missions = db.prepare('SELECT * FROM missions ORDER BY sort_order').all();
  res.render('lab-missions', {
    active: 'lab',
    page: { title: '이번 주 미션', description: '작은 실천이 큰 변화를 만듭니다.' },
    missions,
  });
});

router.get('/lab/resources', (req, res) => {
  const resources = db.prepare('SELECT * FROM resources ORDER BY sort_order').all();
  res.render('lab-resources', {
    active: 'lab',
    page: { title: '자료실', description: '유용한 가이드와 참고자료를 다운로드하세요.' },
    resources,
  });
});

router.get('/about', (req, res) => {
  const page = getPage('about');
  const missionPoints = db.prepare('SELECT * FROM features WHERE page = ? ORDER BY sort_order').all('about-mission');
  const values = db.prepare('SELECT * FROM values_list ORDER BY sort_order').all();
  const story = db.prepare('SELECT * FROM story_timeline ORDER BY sort_order').all();
  const repRow = db.prepare('SELECT * FROM representative LIMIT 1').get();
  const representative = repRow
    ? { ...repRow, bio: JSON.parse(repRow.bio), credentials: JSON.parse(repRow.credentials) }
    : null;
  res.render('about', { active: 'about', page, missionPoints, values, story, representative });
});

router.get('/about/story', (req, res) => {
  const story = db.prepare('SELECT * FROM story_timeline ORDER BY sort_order').all();
  res.render('about-story', {
    active: 'about',
    page: { title: '회사 연혁', description: '라이프디자인컴퍼니가 걸어온 길입니다.' },
    story,
  });
});

router.get('/programs', (req, res) => {
  const page = getPage('programs');
  const features = db.prepare('SELECT * FROM features WHERE page = ? ORDER BY sort_order').all('programs');
  const services = db.prepare('SELECT * FROM services ORDER BY sort_order').all();
  const steps = db.prepare('SELECT * FROM process_steps ORDER BY sort_order').all();
  res.render('programs', { active: 'programs', page, features, services, steps });
});

router.get('/community', (req, res) => {
  const page = getPage('community');
  const category = req.query.category || 'all';
  let posts;
  if (category === 'all') {
    posts = db.prepare("SELECT * FROM community_posts WHERE status = 'published' ORDER BY sort_order").all();
  } else {
    posts = db
      .prepare("SELECT * FROM community_posts WHERE status = 'published' AND category = ? ORDER BY sort_order")
      .all(category);
  }
  const categories = ['all', '공지', '후기', 'Q&A'];
  res.render('community', { active: 'community', page, posts, categories, currentCategory: category });
});

router.post('/community/posts', (req, res) => {
  const body = req.body || {};
  const category = String(body.category || '').trim();
  const author = String(body.author || '').trim();
  const title = String(body.title || '').trim();
  const excerpt = String(body.excerpt || '').trim();

  const allowedCategories = ['후기', 'Q&A'];
  if (!allowedCategories.includes(category) || !author || !title || !excerpt) {
    return res.status(400).json({ ok: false, error: '구분, 이름, 제목, 내용을 모두 입력해주세요.' });
  }
  if (author.length > 30 || title.length > 100 || excerpt.length > 2000) {
    return res.status(400).json({ ok: false, error: '입력 길이를 확인해주세요.' });
  }

  const maxOrder = db.prepare('SELECT MAX(sort_order) AS m FROM community_posts').get();
  const nextOrder = (maxOrder.m ?? -1) + 1;
  const postDate = new Date().toISOString().slice(0, 10);

  db.prepare(
    `INSERT INTO community_posts (category, title, excerpt, post_date, author, status, sort_order)
     VALUES (?, ?, ?, ?, ?, 'pending', ?)`
  ).run(category, title, excerpt, postDate, author, nextOrder);

  res.json({ ok: true });
});

module.exports = router;
