const DIAGNOSTIC_CONTENT = [
  {
    title: '우리 가족 금융 건강검진',
    description: '가족의 재무 상태를 한눈에 점검해보세요.',
    time_tag: '5분 진단',
    icon: 'clipboard-check',
    questions: [
      '매달 가계부를 작성하고 지출을 점검한다',
      '생활비 3개월치 이상의 비상금을 따로 마련해두었다',
      '가족 구성원의 보험 보장 내용을 알고 있다',
      '매달 일정 금액을 저축하거나 투자하고 있다',
      '대출·카드빚 상환 계획이 명확하다',
    ],
  },
  {
    title: '보험 점검 진단',
    description: '보장 공백과 과보장을 쉽게 확인해보세요.',
    time_tag: '3분 진단',
    icon: 'shield-check',
    questions: [
      '가족 구성원 모두 실비보험에 가입되어 있다',
      '보장 내용을 최근 1년 내 점검한 적이 있다',
      '중복 가입된 보험이 없는지 확인했다',
      '사망보장과 진단비 보장이 충분하다고 생각한다',
      '보험료가 소득 대비 적정 수준이다',
    ],
  },
  {
    title: '은퇴 준비 진단',
    description: '은퇴 준비 수준을 점검하고 필요 자금을 예측해보세요.',
    time_tag: '7분 진단',
    icon: 'piggy-bank',
    questions: [
      '국민연금 예상 수령액을 확인해본 적이 있다',
      '개인연금(연금저축·IRP 등)에 가입되어 있다',
      '은퇴 후 필요한 생활비를 계산해본 적이 있다',
      '은퇴 시점과 목표 자산을 구체적으로 정했다',
      '은퇴 후 소득 공백 기간에 대한 대비책이 있다',
    ],
  },
  {
    title: '자산 포트폴리오 진단',
    description: '자산 배분이 적절한지 확인해보세요.',
    time_tag: '5분 진단',
    icon: 'pie-chart',
    questions: [
      '내 자산이 부동산·현금·금융상품 등으로 분산되어 있다',
      '투자 자산의 위험도를 파악하고 있다',
      '정기적으로 포트폴리오를 리밸런싱한다',
      '단기·중기·장기 목표에 맞게 자산을 배분했다',
      '투자 손실을 감내할 수 있는 범위를 알고 있다',
    ],
  },
];

const RESULT_TIER_DEFAULTS = [
  ['high', '우수해요!', '체계적으로 잘 관리하고 계세요. 지금의 습관을 유지하면서 정기적으로 점검해보세요.'],
  ['mid', '양호해요', '기본은 갖추셨지만 보완할 부분이 있어요. 전문가와의 상담으로 부족한 부분을 채워보세요.'],
  ['low', '주의가 필요해요', '지금부터 하나씩 준비해보세요. 전문가와의 1:1 상담으로 구체적인 계획을 세워보시길 추천드립니다.'],
];

// diagnostics 테이블에 DIAGNOSTIC_CONTENT의 제목과 일치하는 행이 있는데
// 문항/결과가 비어 있으면 기본값을 채워 넣는다 (신규 설치 시드 + 기존 DB 마이그레이션 겸용).
function backfillDiagnosticContent(db) {
  const insertQuestion = db.prepare(
    'INSERT INTO diagnostic_questions (diagnostic_id, question, sort_order) VALUES (?, ?, ?)'
  );
  const insertResultTier = db.prepare(
    'INSERT INTO diagnostic_results (diagnostic_id, tier, title, description) VALUES (?, ?, ?, ?)'
  );

  DIAGNOSTIC_CONTENT.forEach((d) => {
    const row = db.prepare('SELECT id FROM diagnostics WHERE title = ?').get(d.title);
    if (!row) return;
    const diagnosticId = row.id;

    const qCount = db
      .prepare('SELECT COUNT(*) AS c FROM diagnostic_questions WHERE diagnostic_id = ?')
      .get(diagnosticId).c;
    if (qCount === 0) {
      d.questions.forEach((q, qi) => insertQuestion.run(diagnosticId, q, qi));
    }

    const rCount = db
      .prepare('SELECT COUNT(*) AS c FROM diagnostic_results WHERE diagnostic_id = ?')
      .get(diagnosticId).c;
    if (rCount === 0) {
      RESULT_TIER_DEFAULTS.forEach((t) => insertResultTier.run(diagnosticId, t[0], t[1], t[2]));
    }
  });
}

function seed(db) {
  const insertPage = db.prepare(
    'INSERT INTO pages (slug, title, subtitle, description) VALUES (?, ?, ?, ?)'
  );
  const insertFeature = db.prepare(
    'INSERT INTO features (page, icon, title, description, sort_order) VALUES (?, ?, ?, ?, ?)'
  );
  const insertCourse = db.prepare(
    'INSERT INTO courses (category, category_label, title, description, duration, level, format, sort_order) VALUES (?, ?, ?, ?, ?, ?, ?, ?)'
  );
  const insertDiagnostic = db.prepare(
    'INSERT INTO diagnostics (title, description, time_tag, icon, sort_order) VALUES (?, ?, ?, ?, ?)'
  );
  const insertWorkbook = db.prepare(
    'INSERT INTO workbooks (num, title, subtitle, icon, color, sort_order) VALUES (?, ?, ?, ?, ?, ?)'
  );
  const insertMission = db.prepare(
    'INSERT INTO missions (num, title, sort_order) VALUES (?, ?, ?)'
  );
  const insertResource = db.prepare(
    'INSERT INTO resources (title, file_type, sort_order) VALUES (?, ?, ?)'
  );
  const insertValue = db.prepare(
    'INSERT INTO values_list (num, title, description, sort_order) VALUES (?, ?, ?, ?)'
  );
  const insertStory = db.prepare(
    'INSERT INTO story_timeline (year, description, sort_order) VALUES (?, ?, ?)'
  );
  const insertRep = db.prepare(
    'INSERT INTO representative (name, role, bio, credentials, quote, email, phone) VALUES (?, ?, ?, ?, ?, ?, ?)'
  );
  const insertService = db.prepare(
    'INSERT INTO services (category, title, description, icon, sort_order) VALUES (?, ?, ?, ?, ?)'
  );
  const insertProcess = db.prepare(
    'INSERT INTO process_steps (num, title, description, sort_order) VALUES (?, ?, ?, ?)'
  );
  const insertPost = db.prepare(
    'INSERT INTO community_posts (category, title, excerpt, post_date, sort_order) VALUES (?, ?, ?, ?, ?)'
  );

  function runSeed() {
    // ---------- PAGES (hero copy) ----------
    insertPage.run(
      'home',
      '삶을 설계하는 시간',
      'Life Design Company와 함께 만드는 나만의 생애 금융 설계',
      '생애주기별 맞춤 금융교육과 실천 프로그램으로, 막연한 미래를 구체적인 삶의 설계로 바꿔드립니다.'
    );
    insertPage.run(
      'academy',
      'ACADEMY',
      '삶을 설계하는 힘, 라이프디자인컴퍼니 아카데미',
      '금융 지식부터 실천 습관까지, 전문가의 체계적인 교육으로 함께 성장합니다.'
    );
    insertPage.run(
      'lab',
      'Life Design Lab',
      '교육에서 끝나지 않습니다. 실천이 변화를 만들고, 변화가 삶을 디자인합니다.',
      '라이프디자인랩은 당신의 삶을 설계하고 실천할 수 있도록 돕는 실용적인 도구와 콘텐츠를 제공합니다.'
    );
    insertPage.run(
      'about',
      'Life Design Company',
      '우리는 금융을 통해 당신의 삶을 더 설계답게 만듭니다.',
      '돈을 잘 관리하는 방법을 넘어, 당신의 삶을 주도적으로 디자인할 수 있도록 함께 고민하고, 함께 성장합니다.'
    );
    insertPage.run(
      'programs',
      'PROGRAMS',
      '생애주기와 상황에 맞는 라이프디자인컴퍼니의 금융 설계 프로그램',
      '1:1 맞춤 진단부터 실행 설계, 사후관리까지 이어지는 라이프디자인컴퍼니만의 프로그램을 만나보세요.'
    );
    insertPage.run(
      'community',
      'COMMUNITY',
      '함께 성장하는 라이프디자인컴퍼니 커뮤니티',
      '공지사항과 교육 후기, 궁금한 점을 나누며 삶을 설계하는 여정을 함께합니다.'
    );

    // ---------- ACADEMY ----------
    const academyFeatures = [
      ['person', '전문가 직강', '금융·자산관리 분야 전문가의 직접 강의'],
      ['book', '체계적인 커리큘럼', '기초부터 심화까지 단계별 맞춤 커리큘럼'],
      ['flag', '실생활 적용', '배운 내용을 바로 실천할 수 있는 실용적인 교육'],
      ['people', '온·오프라인', '오프라인 현장 교육과 온라인 강의 병행'],
    ];
    academyFeatures.forEach((f, i) => insertFeature.run('academy', f[0], f[1], f[2], i));

    const courses = [
      ['prep', '예비·신혼', '행복한 부모가 되기 위한 똑똑한 금융 준비', '산모와 예비 부모를 위한 재정 설계와 자녀 교육비 준비 방법을 알려드립니다.', '2시간', '초급', '오프라인'],
      ['family', '가정·자녀', '우리 가족을 위한 똑똑한 자산관리', '가계 재무관리부터 자녀 교육, 보험까지 가정 경제의 기초를 탄탄하게!', '2시간', '초급', '오프라인'],
      ['finance', '재무·자산', '직장인을 위한 재무설계 A to Z', '급여관리부터 투자, 절세까지 직장인의 재테크 전략을 모두 담았습니다.', '2.5시간', '중급', '온라인'],
      ['retire', '은퇴·노후', '행복한 은퇴를 위한 노후 설계 전략', '은퇴 후 삶의 질을 높이는 연금 설계와 노후 자산관리 방법을 배워보세요.', '2.5시간', '중급', '오프라인'],
      ['inherit', '상속·증여', '슬기로운 상속·증여 절세 플랜', '가족에게 물려줄 자산을 지키는 상속·증여 절세 전략을 사례로 배웁니다.', '2시간', '중급', '온라인'],
      ['family', '가정·자녀', '자녀 경제교육, 어떻게 시작할까요?', '용돈관리부터 첫 통장까지, 우리 아이 눈높이에 맞춘 경제교육 노하우.', '1.5시간', '초급', '오프라인'],
    ];
    courses.forEach((c, i) => insertCourse.run(c[0], c[1], c[2], c[3], c[4], c[5], c[6], i));

    const differentiators = [
      ['bullseye', '생애주기 맞춤 교육', '연령과 상황에 맞는 맞춤형 교육 제공'],
      ['graph-up', '실전 중심 교육', '실제 사례와 실습으로 바로 적용 가능한 교육'],
      ['people', '전문 강사진', '풍부한 실무 경험을 가진 금융·자산관리 전문가'],
      ['file-text', '지속적인 관리', '교육 후 1:1 상담 및 사후 관리 지원'],
    ];
    differentiators.forEach((f, i) => insertFeature.run('academy-diff', f[0], f[1], f[2], i));

    // ---------- LAB ----------
    const labFeatures = [
      ['activity', '진단 도구', '지금 내 상황을 점검하고 우선순위를 확인해보세요.'],
      ['book', '워크북', '가족과 함께 생각을 정리하고 계획을 세워보세요.'],
      ['journal-text', '툴킷', '실생활에 바로 사용하는 템플릿과 체크리스트'],
      ['bullseye', '미션', '작은 실천이 큰 변화를 만듭니다. 오늘의 미션을 시작해보세요.'],
      ['folder', '자료실', '유용한 가이드와 참고자료를 다운로드하세요.'],
    ];
    labFeatures.forEach((f, i) => insertFeature.run('lab', f[0], f[1], f[2], i));

    DIAGNOSTIC_CONTENT.forEach((d, i) => {
      insertDiagnostic.run(d.title, d.description, d.time_tag, d.icon, i);
    });
    backfillDiagnosticContent(db);

    const workbooks = [
      ['01', '우리 가족 금융 건강검진', '', 'heart-pulse', 'green'],
      ['02', '2035년의 우리가족', '', 'calendar', 'navy'],
      ['03', '우리집 경제 MBTI', '', 'emoji-smile', 'peach'],
      ['04', '현명한 소비 습관 체크리스트', '', 'list-check', 'cream'],
      ['05', '비상금 & 목표자금 계획표', '', 'coin', 'gold'],
    ];
    workbooks.forEach((w, i) => insertWorkbook.run(w[0], w[1], w[2], w[3], w[4], i));

    const missions = [
      ['01', '가족의 한 달 지출 내역 정리하기'],
      ['02', '보험 증권 목록 만들기'],
      ['03', '비상금 목표 금액 설정하기'],
    ];
    missions.forEach((m, i) => insertMission.run(m[0], m[1], i));

    const resources = [
      ['생애주기별 자산관리 가이드', 'PDF'],
      ['연금 기초 가이드', 'PDF'],
      ['보험 기본 가이드', 'PDF'],
      ['상속·증여 절세 가이드', 'PDF'],
    ];
    resources.forEach((r, i) => insertResource.run(r[0], r[1], i));

    // ---------- ABOUT ----------
    const missionPoints = [
      ['people', '삶 중심의 금융교육', '단순한 금융 정보가 아닌 삶의 맥락에서 배우는 교육을 지향합니다.'],
      ['compass', '실천 가능한 변화', '배운 내용을 일상에서 실천하고, 습관으로 만들 수 있도록 돕습니다.'],
      ['heart', '함께 성장하는 파트너', '고객의 인생 여정에 함께하며 든든한 동반자가 되겠습니다.'],
    ];
    missionPoints.forEach((f, i) => insertFeature.run('about-mission', f[0], f[1], f[2], i));

    const values = [
      ['01', '신뢰', '정확하고 객관적인 정보로 신뢰를 쌓아갑니다.'],
      ['02', '전문성', '깊이 있는 전문성을 바탕으로 최적의 솔루션을 제공합니다.'],
      ['03', '맞춤', '사람마다 다른 삶에 맞춘 맞춤형 교육을 제공합니다.'],
      ['04', '실천', '배우는 것을 넘어 실천하고 변화합니다.'],
    ];
    values.forEach((v, i) => insertValue.run(v[0], v[1], v[2], i));

    const story = [
      ['2024', '라이프디자인컴퍼니 설립'],
      ['2024', '산후조리원 금융교육 프로그램 론칭'],
      ['2024', '기업·공공기관 교육 프로그램 확대'],
      ['2025', 'Life Design Lab 론칭'],
      ['2025', '맞춤형 생애 설계 교육 브랜드로 성장'],
    ];
    story.forEach((s, i) => insertStory.run(s[0], s[1], i));

    insertRep.run(
      '박지은',
      '대표',
      JSON.stringify([
        '삶을 더 나은 방향으로 디자인할 수 있도록',
        '전문성과 진심을 담아 교육합니다.',
      ]),
      JSON.stringify([
        { icon: 'award', title: 'CFP®', desc: '국제공인재무설계사' },
        { icon: 'patch-check', title: 'AFP®K', desc: '국내공인재무설계사' },
        { icon: 'mortarboard', title: '금융·자산관리 전문가', desc: '' },
        { icon: 'briefcase', title: '교육 경력 20년 이상', desc: '' },
      ]),
      '금융은 결국 사람의 삶을 위한 도구입니다. 더 나은 선택이 쌓여, 더 나은 삶이 됩니다.',
      'contact@lifedesign.co.kr',
      '02-000-0000'
    );

    // ---------- PROGRAMS ----------
    const progFeatures = [
      ['person-check', '1:1 맞춤 상담', '전문 컨설턴트와의 밀착 상담으로 진행합니다.'],
      ['clipboard-data', '데이터 기반 진단', '재무 데이터를 기반으로 객관적으로 진단합니다.'],
      ['people', '전문가 매칭', '상황에 맞는 최적의 전문가를 매칭해드립니다.'],
      ['arrow-repeat', '사후관리', '설계 이후에도 지속적으로 관리해드립니다.'],
    ];
    progFeatures.forEach((f, i) => insertFeature.run('programs', f[0], f[1], f[2], i));

    const services = [
      ['예비·신혼', '예비 부모를 위한 재무설계 상담', '출산과 육아를 앞둔 가정을 위한 맞춤형 재정 설계를 제공합니다.', 'person-hearts'],
      ['가정·자녀', '가족 자산관리 컨설팅', '가계부 진단부터 교육비, 보험까지 통합적으로 컨설팅합니다.', 'house-heart'],
      ['재무·자산', '직장인 재무 클리닉', '급여 관리, 투자, 절세를 아우르는 1:1 재무 클리닉입니다.', 'briefcase'],
      ['은퇴·노후', '은퇴설계 컨설팅', '은퇴 후 삶을 위한 연금과 자산 인출 전략을 설계합니다.', 'sunrise'],
      ['상속·증여', '상속·증여 플래닝', '세대를 잇는 자산 이전을 위한 절세 플랜을 제안합니다.', 'file-earmark-text'],
    ];
    services.forEach((s, i) => insertService.run(s[0], s[1], s[2], s[3], i));

    const process = [
      ['01', '상담 신청', '홈페이지 또는 전화로 간편하게 신청합니다.'],
      ['02', '재무 진단', '현재 상황을 데이터 기반으로 진단합니다.'],
      ['03', '1:1 상담', '전문 컨설턴트와 목표를 구체화합니다.'],
      ['04', '설계안 제공', '맞춤형 실행 설계안을 제공합니다.'],
      ['05', '사후 관리', '실행 이후에도 지속적으로 관리합니다.'],
    ];
    process.forEach((p, i) => insertProcess.run(p[0], p[1], p[2], i));

    // ---------- COMMUNITY ----------
    const posts = [
      ['공지', '2025년 하반기 아카데미 정규 과정 안내', '하반기 정규 과정 일정과 신청 방법을 안내드립니다.', '2025-08-20'],
      ['공지', '추석 연휴 상담 운영 안내', '연휴 기간 상담 운영 일정을 확인해주세요.', '2025-09-01'],
      ['후기', '재무설계 A to Z 수강 후기', '막연했던 재테크가 구체적인 계획으로 바뀌었어요.', '2025-08-15'],
      ['후기', '가족 자산관리 컨설팅 후기', '가족 모두가 함께 참여해서 더 의미있었습니다.', '2025-08-05'],
      ['Q&A', '온라인 강의도 수료증이 나오나요?', '네, 모든 정규 과정은 온·오프라인 관계없이 수료증을 제공합니다.', '2025-07-28'],
      ['Q&A', '기업 단체 교육도 가능한가요?', '기업·공공기관 대상 맞춤형 단체 교육을 운영하고 있습니다.', '2025-07-10'],
    ];
    posts.forEach((p, i) => insertPost.run(p[0], p[1], p[2], p[3], i));
  }

  db.exec('BEGIN');
  try {
    runSeed();
    db.exec('COMMIT');
  } catch (err) {
    db.exec('ROLLBACK');
    throw err;
  }
}

module.exports = seed;
module.exports.backfillDiagnosticContent = backfillDiagnosticContent;
