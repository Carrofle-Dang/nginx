const path = require('path');
const fs = require('fs');
const multer = require('multer');

const uploadsRoot = path.join(__dirname, '..', 'public', 'uploads');

const DOCUMENT_EXTENSIONS = ['.pdf', '.doc', '.docx', '.hwp', '.xls', '.xlsx', '.ppt', '.pptx'];

function subDirFor(fieldname) {
  if (fieldname === 'video') return 'videos';
  if (fieldname === 'file') return 'files';
  return 'images';
}

const storage = multer.diskStorage({
  destination(req, file, cb) {
    const dir = path.join(uploadsRoot, subDirFor(file.fieldname));
    fs.mkdirSync(dir, { recursive: true });
    cb(null, dir);
  },
  filename(req, file, cb) {
    const ext = path.extname(file.originalname).toLowerCase();
    const unique = `${Date.now()}-${Math.round(Math.random() * 1e9)}${ext}`;
    cb(null, unique);
  },
});

function fileFilter(req, file, cb) {
  if ((file.fieldname === 'image' || file.fieldname === 'photo') && file.mimetype.startsWith('image/')) {
    return cb(null, true);
  }
  if (file.fieldname === 'video' && file.mimetype.startsWith('video/')) {
    return cb(null, true);
  }
  if (file.fieldname === 'file' && DOCUMENT_EXTENSIONS.includes(path.extname(file.originalname).toLowerCase())) {
    return cb(null, true);
  }
  cb(new Error('허용되지 않는 파일 형식입니다.'));
}

const upload = multer({
  storage,
  fileFilter,
  limits: { fileSize: 200 * 1024 * 1024 }, // 200MB
});

// multer/파일시스템 오류를 관리자가 이해할 수 있는 문구로 바꿔준다.
// (특히 ENOSPC는 서버 디스크 용량이 가득 찼을 때 발생 — 업로드가 반복될수록
// 점점 더 작은 크기에서도 실패하는 것처럼 보이는 원인이 대부분 이것이다.)
function friendlyUploadError(err) {
  if (!err) return null;
  if (err.code === 'ENOSPC') {
    return '서버 저장 공간이 가득 찼습니다. 관리자에게 문의해 디스크 여유 공간을 확보해주세요.';
  }
  if (err.code === 'LIMIT_FILE_SIZE') {
    return '파일 용량이 너무 큽니다 (최대 200MB).';
  }
  return err.message || '파일 업로드 중 오류가 발생했습니다.';
}

module.exports = upload;
module.exports.friendlyUploadError = friendlyUploadError;
