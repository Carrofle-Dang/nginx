const express = require('express');
const fs = require('fs');
const path = require('path');
const db = require('../db/database');
const ensureAdmin = require('../middleware/ensureAdmin');
const upload = require('../middleware/upload');
const adminAuth = require('../config/admin-auth');

const router = express.Router();

const CATEGORIES = [
  { key: 'prep', label: '예비·신혼' },
  { key: 'family', label: '가정·자녀' },
  { key: 'finance', label: '재무·자산' },
  { key: 'retire', label: '은퇴·노후' },
  { key: 'inherit', label: '상속·증여' },
];

const PAGE_LABELS = {
  home: '홈',
  academy: 'ACADEMY',
  lab: 'LAB',
  about: 'ABOUT',
  programs: 'PROGRAMS',
  community: 'COMMUNITY',
};

function categoryLabel(key) {
  const found = CATEGORIES.find((c) => c.key === key);
  return found ? found.label : key;
}

function removeUploadedFile(relativePath) {
  if (!relativePath) return;
  const filePath = path.join(__dirname, '..', 'public', relativePath);
  fs.unlink(filePath, () => {}); // best-effort, ignore errors
}

const courseUpload = upload.fields([
  { name: 'image', maxCount: 1 },
  { name: 'video', maxCount: 1 },
]);

function handleCourseUpload(req, res, next) {
  courseUpload(req, res, (err) => {
    if (err) req.uploadError = upload.friendlyUploadError(err);
    next();
  });
}

const heroUpload = upload.fields([
  { name: 'image', maxCount: 1 },
  { name: 'video', maxCount: 1 },
]);

function handleHeroUpload(req, res, next) {
  heroUpload(req, res, (err) => {
    if (err) req.uploadError = upload.friendlyUploadError(err);
    next();
  });
}

const repPhotoUpload = upload.single('photo');

function handleRepPhotoUpload(req, res, next) {
  repPhotoUpload(req, res, (err) => {
    if (err) req.uploadError = upload.friendlyUploadError(err);
    next();
  });
}

const COMMUNITY_CATEGORIES = ['공지', '후기', 'Q&A'];

const WORKBOOK_COLORS = ['green', 'navy', 'peach', 'cream', 'gold'];

const workbookUpload = upload.single('file');

function handleWorkbookUpload(req, res, next) {
  workbookUpload(req, res, (err) => {
    if (err) req.uploadError = upload.friendlyUploadError(err);
    next();
  });
}

// ---------- Auth ----------
router.get('/login', (req, res) => {
  res.render('admin/login', { error: req.query.error || null });
});

router.post('/login', (req, res) => {
  const { username, password } = req.body;
  if (username === adminAuth.username && password === adminAuth.password) {
    req.session.isAdmin = true;
    return res.redirect('/admin');
  }
  res.redirect('/admin/login?error=' + encodeURIComponent('아이디 또는 비밀번호가 올바르지 않습니다.'));
});

router.post('/logout', (req, res) => {
  req.session.destroy(() => res.redirect('/admin/login'));
});

router.use((req, res, next) => {
  if (req.session && req.session.isAdmin) {
    const row = db.prepare(`SELECT COUNT(*) AS c FROM consultations WHERE status = 'new'`).get();
    res.locals.unreadCount = row.c;
    const pendingRow = db.prepare(`SELECT COUNT(*) AS c FROM community_posts WHERE status = 'pending'`).get();
    res.locals.pendingPostCount = pendingRow.c;
  } else {
    res.locals.unreadCount = 0;
    res.locals.pendingPostCount = 0;
  }
  next();
});

router.get('/', ensureAdmin, (req, res) => res.redirect('/admin/courses'));

// =====================================================================
// 교육 프로그램 (courses) — ACADEMY 페이지
// =====================================================================
router.get('/courses', ensureAdmin, (req, res) => {
  const courses = db.prepare('SELECT * FROM courses ORDER BY sort_order').all();
  res.render('admin/dashboard', { courses });
});

router.get('/courses/new', ensureAdmin, (req, res) => {
  res.render('admin/form', { mode: 'new', course: null, categories: CATEGORIES, error: req.query.error || null });
});

router.post('/courses', ensureAdmin, handleCourseUpload, (req, res) => {
  if (req.uploadError) {
    return res.redirect('/admin/courses/new?error=' + encodeURIComponent(req.uploadError));
  }
  const { category, title, description, duration, level, format } = req.body;
  const imageFile = req.files && req.files.image && req.files.image[0];
  const videoFile = req.files && req.files.video && req.files.video[0];
  const imagePath = imageFile ? `/uploads/images/${imageFile.filename}` : null;
  const videoPath = videoFile ? `/uploads/videos/${videoFile.filename}` : null;

  const maxOrder = db.prepare('SELECT MAX(sort_order) AS m FROM courses').get();
  const nextOrder = (maxOrder.m ?? -1) + 1;

  db.prepare(
    `INSERT INTO courses (category, category_label, title, description, duration, level, format, image_path, video_path, sort_order)
     VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`
  ).run(category, categoryLabel(category), title, description, duration, level, format, imagePath, videoPath, nextOrder);

  res.redirect('/admin/courses');
});

router.get('/courses/:id/edit', ensureAdmin, (req, res) => {
  const course = db.prepare('SELECT * FROM courses WHERE id = ?').get(req.params.id);
  if (!course) return res.redirect('/admin/courses');
  res.render('admin/form', { mode: 'edit', course, categories: CATEGORIES, error: req.query.error || null });
});

router.post('/courses/:id', ensureAdmin, handleCourseUpload, (req, res) => {
  const course = db.prepare('SELECT * FROM courses WHERE id = ?').get(req.params.id);
  if (!course) return res.redirect('/admin/courses');

  if (req.uploadError) {
    return res.redirect(`/admin/courses/${req.params.id}/edit?error=` + encodeURIComponent(req.uploadError));
  }

  const { category, title, description, duration, level, format, remove_image, remove_video } = req.body;
  const imageFile = req.files && req.files.image && req.files.image[0];
  const videoFile = req.files && req.files.video && req.files.video[0];

  let imagePath = course.image_path;
  if (imageFile) {
    removeUploadedFile(course.image_path);
    imagePath = `/uploads/images/${imageFile.filename}`;
  } else if (remove_image) {
    removeUploadedFile(course.image_path);
    imagePath = null;
  }

  let videoPath = course.video_path;
  if (videoFile) {
    removeUploadedFile(course.video_path);
    videoPath = `/uploads/videos/${videoFile.filename}`;
  } else if (remove_video) {
    removeUploadedFile(course.video_path);
    videoPath = null;
  }

  db.prepare(
    `UPDATE courses SET category = ?, category_label = ?, title = ?, description = ?, duration = ?, level = ?, format = ?, image_path = ?, video_path = ?
     WHERE id = ?`
  ).run(category, categoryLabel(category), title, description, duration, level, format, imagePath, videoPath, req.params.id);

  res.redirect('/admin/courses');
});

router.post('/courses/:id/delete', ensureAdmin, (req, res) => {
  const course = db.prepare('SELECT * FROM courses WHERE id = ?').get(req.params.id);
  if (course) {
    removeUploadedFile(course.image_path);
    removeUploadedFile(course.video_path);
    db.prepare('DELETE FROM courses WHERE id = ?').run(req.params.id);
  }
  res.redirect('/admin/courses');
});

// =====================================================================
// 상담 서비스 (services) — PROGRAMS 페이지
// =====================================================================
router.get('/services', ensureAdmin, (req, res) => {
  const services = db.prepare('SELECT * FROM services ORDER BY sort_order').all();
  res.render('admin/services', { services, categories: CATEGORIES });
});

router.get('/services/new', ensureAdmin, (req, res) => {
  res.render('admin/service-form', { mode: 'new', service: null, categories: CATEGORIES, error: req.query.error || null });
});

router.post('/services', ensureAdmin, (req, res) => {
  const { category, title, description, icon } = req.body;
  if (!category || !title) {
    return res.redirect('/admin/services/new?error=' + encodeURIComponent('카테고리와 제목은 필수입니다.'));
  }
  const maxOrder = db.prepare('SELECT MAX(sort_order) AS m FROM services').get();
  const nextOrder = (maxOrder.m ?? -1) + 1;
  db.prepare(
    `INSERT INTO services (category, title, description, icon, sort_order) VALUES (?, ?, ?, ?, ?)`
  ).run(category, title, description, icon || 'star', nextOrder);
  res.redirect('/admin/services');
});

router.get('/services/:id/edit', ensureAdmin, (req, res) => {
  const service = db.prepare('SELECT * FROM services WHERE id = ?').get(req.params.id);
  if (!service) return res.redirect('/admin/services');
  res.render('admin/service-form', { mode: 'edit', service, categories: CATEGORIES, error: req.query.error || null });
});

router.post('/services/:id', ensureAdmin, (req, res) => {
  const { category, title, description, icon } = req.body;
  if (!category || !title) {
    return res.redirect(`/admin/services/${req.params.id}/edit?error=` + encodeURIComponent('카테고리와 제목은 필수입니다.'));
  }
  db.prepare(
    `UPDATE services SET category = ?, title = ?, description = ?, icon = ? WHERE id = ?`
  ).run(category, title, description, icon || 'star', req.params.id);
  res.redirect('/admin/services');
});

router.post('/services/:id/delete', ensureAdmin, (req, res) => {
  db.prepare('DELETE FROM services WHERE id = ?').run(req.params.id);
  res.redirect('/admin/services');
});

// =====================================================================
// 메인 배너 이미지 (pages.hero_image) — 홈/각 페이지 상단 배너
// =====================================================================
router.get('/pages', ensureAdmin, (req, res) => {
  const pages = db.prepare('SELECT * FROM pages').all();
  const ordered = ['home', 'academy', 'lab', 'about', 'programs', 'community']
    .map((slug) => pages.find((p) => p.slug === slug))
    .filter(Boolean);
  res.render('admin/pages', { pages: ordered, pageLabels: PAGE_LABELS });
});

router.get('/pages/:slug/edit', ensureAdmin, (req, res) => {
  const page = db.prepare('SELECT * FROM pages WHERE slug = ?').get(req.params.slug);
  if (!page) return res.redirect('/admin/pages');
  res.render('admin/page-form', { page, pageLabels: PAGE_LABELS, error: req.query.error || null });
});

router.post('/pages/:slug', ensureAdmin, handleHeroUpload, (req, res) => {
  const page = db.prepare('SELECT * FROM pages WHERE slug = ?').get(req.params.slug);
  if (!page) return res.redirect('/admin/pages');

  if (req.uploadError) {
    return res.redirect(`/admin/pages/${req.params.slug}/edit?error=` + encodeURIComponent(req.uploadError));
  }

  const { remove_image, remove_video } = req.body;
  const imageFile = req.files && req.files.image && req.files.image[0];
  const videoFile = req.files && req.files.video && req.files.video[0];

  let heroImage = page.hero_image;
  if (imageFile) {
    removeUploadedFile(page.hero_image);
    heroImage = `/uploads/images/${imageFile.filename}`;
  } else if (remove_image) {
    removeUploadedFile(page.hero_image);
    heroImage = null;
  }

  let heroVideo = page.video_path;
  if (videoFile) {
    removeUploadedFile(page.video_path);
    heroVideo = `/uploads/videos/${videoFile.filename}`;
  } else if (remove_video) {
    removeUploadedFile(page.video_path);
    heroVideo = null;
  }

  db.prepare('UPDATE pages SET hero_image = ?, video_path = ? WHERE slug = ?').run(
    heroImage,
    heroVideo,
    req.params.slug
  );
  res.redirect('/admin/pages');
});

// =====================================================================
// 상담 신청/문의 접수 내역
// =====================================================================
router.get('/consultations', ensureAdmin, (req, res) => {
  const consultations = db.prepare('SELECT * FROM consultations ORDER BY created_at DESC, id DESC').all();
  res.render('admin/consultations', { consultations });
});

router.post('/consultations/:id/read', ensureAdmin, (req, res) => {
  db.prepare(`UPDATE consultations SET status = 'read' WHERE id = ?`).run(req.params.id);
  res.redirect('/admin/consultations');
});

router.post('/consultations/:id/delete', ensureAdmin, (req, res) => {
  db.prepare('DELETE FROM consultations WHERE id = ?').run(req.params.id);
  res.redirect('/admin/consultations');
});

// =====================================================================
// 진단 도구 (diagnostics) — LAB 페이지 "진단하기"
// =====================================================================
const TIER_LABELS = { high: '우수 (70% 이상)', mid: '양호 (40~69%)', low: '주의 필요 (40% 미만)' };

router.get('/diagnostics', ensureAdmin, (req, res) => {
  const diagnostics = db.prepare('SELECT * FROM diagnostics ORDER BY sort_order').all();
  const withCounts = diagnostics.map((d) => {
    const qCount = db.prepare('SELECT COUNT(*) AS c FROM diagnostic_questions WHERE diagnostic_id = ?').get(d.id).c;
    return { ...d, questionCount: qCount };
  });
  res.render('admin/diagnostics', { diagnostics: withCounts });
});

router.get('/diagnostics/new', ensureAdmin, (req, res) => {
  res.render('admin/diagnostic-form', { diagnostic: null, error: req.query.error || null });
});

router.post('/diagnostics', ensureAdmin, (req, res) => {
  const { title, description, time_tag, icon } = req.body;
  if (!title) {
    return res.redirect('/admin/diagnostics/new?error=' + encodeURIComponent('제목은 필수입니다.'));
  }
  const maxOrder = db.prepare('SELECT MAX(sort_order) AS m FROM diagnostics').get();
  const nextOrder = (maxOrder.m ?? -1) + 1;
  const result = db
    .prepare('INSERT INTO diagnostics (title, description, time_tag, icon, sort_order) VALUES (?, ?, ?, ?, ?)')
    .run(title, description, time_tag, icon || 'clipboard-check', nextOrder);

  const diagnosticId = result.lastInsertRowid;
  ['high', 'mid', 'low'].forEach((tier) => {
    db.prepare('INSERT INTO diagnostic_results (diagnostic_id, tier, title, description) VALUES (?, ?, ?, ?)').run(
      diagnosticId,
      tier,
      '',
      ''
    );
  });

  res.redirect(`/admin/diagnostics/${diagnosticId}`);
});

router.get('/diagnostics/:id', ensureAdmin, (req, res) => {
  const diagnostic = db.prepare('SELECT * FROM diagnostics WHERE id = ?').get(req.params.id);
  if (!diagnostic) return res.redirect('/admin/diagnostics');
  const questions = db
    .prepare('SELECT * FROM diagnostic_questions WHERE diagnostic_id = ? ORDER BY sort_order')
    .all(diagnostic.id);
  const resultRows = db.prepare('SELECT * FROM diagnostic_results WHERE diagnostic_id = ?').all(diagnostic.id);
  const results = { high: null, mid: null, low: null };
  resultRows.forEach((r) => {
    results[r.tier] = r;
  });

  res.render('admin/diagnostic-detail', {
    diagnostic,
    questions,
    results,
    tierLabels: TIER_LABELS,
    error: req.query.error || null,
  });
});

router.post('/diagnostics/:id', ensureAdmin, (req, res) => {
  const { title, description, time_tag, icon } = req.body;
  if (!title) {
    return res.redirect(`/admin/diagnostics/${req.params.id}?error=` + encodeURIComponent('제목은 필수입니다.'));
  }
  db.prepare('UPDATE diagnostics SET title = ?, description = ?, time_tag = ?, icon = ? WHERE id = ?').run(
    title,
    description,
    time_tag,
    icon || 'clipboard-check',
    req.params.id
  );
  res.redirect(`/admin/diagnostics/${req.params.id}`);
});

router.post('/diagnostics/:id/delete', ensureAdmin, (req, res) => {
  db.prepare('DELETE FROM diagnostic_questions WHERE diagnostic_id = ?').run(req.params.id);
  db.prepare('DELETE FROM diagnostic_results WHERE diagnostic_id = ?').run(req.params.id);
  db.prepare('DELETE FROM diagnostics WHERE id = ?').run(req.params.id);
  res.redirect('/admin/diagnostics');
});

router.post('/diagnostics/:id/questions', ensureAdmin, (req, res) => {
  const question = (req.body.question || '').trim();
  if (question) {
    const maxOrder = db
      .prepare('SELECT MAX(sort_order) AS m FROM diagnostic_questions WHERE diagnostic_id = ?')
      .get(req.params.id);
    const nextOrder = (maxOrder.m ?? -1) + 1;
    db.prepare('INSERT INTO diagnostic_questions (diagnostic_id, question, sort_order) VALUES (?, ?, ?)').run(
      req.params.id,
      question,
      nextOrder
    );
  }
  res.redirect(`/admin/diagnostics/${req.params.id}`);
});

router.post('/diagnostics/:id/questions/:qid/delete', ensureAdmin, (req, res) => {
  db.prepare('DELETE FROM diagnostic_questions WHERE id = ? AND diagnostic_id = ?').run(
    req.params.qid,
    req.params.id
  );
  res.redirect(`/admin/diagnostics/${req.params.id}`);
});

router.post('/diagnostics/:id/results', ensureAdmin, (req, res) => {
  ['high', 'mid', 'low'].forEach((tier) => {
    const title = req.body[`${tier}_title`] || '';
    const description = req.body[`${tier}_description`] || '';
    const existing = db
      .prepare('SELECT id FROM diagnostic_results WHERE diagnostic_id = ? AND tier = ?')
      .get(req.params.id, tier);
    if (existing) {
      db.prepare('UPDATE diagnostic_results SET title = ?, description = ? WHERE id = ?').run(
        title,
        description,
        existing.id
      );
    } else {
      db.prepare('INSERT INTO diagnostic_results (diagnostic_id, tier, title, description) VALUES (?, ?, ?, ?)').run(
        req.params.id,
        tier,
        title,
        description
      );
    }
  });
  res.redirect(`/admin/diagnostics/${req.params.id}`);
});

// =====================================================================
// 워크북 (workbooks) — LAB 페이지 다운로드 자료
// =====================================================================
router.get('/workbooks', ensureAdmin, (req, res) => {
  const workbooks = db.prepare('SELECT * FROM workbooks ORDER BY sort_order').all();
  res.render('admin/workbooks', { workbooks, colors: WORKBOOK_COLORS });
});

router.get('/workbooks/new', ensureAdmin, (req, res) => {
  res.render('admin/workbook-form', { mode: 'new', workbook: null, colors: WORKBOOK_COLORS, error: req.query.error || null });
});

router.post('/workbooks', ensureAdmin, handleWorkbookUpload, (req, res) => {
  if (req.uploadError) {
    return res.redirect('/admin/workbooks/new?error=' + encodeURIComponent(req.uploadError));
  }
  const { num, title, subtitle, icon, color } = req.body;
  if (!title) {
    return res.redirect('/admin/workbooks/new?error=' + encodeURIComponent('제목은 필수입니다.'));
  }
  const filePath = req.file ? `/uploads/files/${req.file.filename}` : null;
  const maxOrder = db.prepare('SELECT MAX(sort_order) AS m FROM workbooks').get();
  const nextOrder = (maxOrder.m ?? -1) + 1;

  db.prepare(
    `INSERT INTO workbooks (num, title, subtitle, icon, color, file_path, sort_order) VALUES (?, ?, ?, ?, ?, ?, ?)`
  ).run(num, title, subtitle || '', icon || 'file-earmark-text', color || 'cream', filePath, nextOrder);

  res.redirect('/admin/workbooks');
});

router.get('/workbooks/:id/edit', ensureAdmin, (req, res) => {
  const workbook = db.prepare('SELECT * FROM workbooks WHERE id = ?').get(req.params.id);
  if (!workbook) return res.redirect('/admin/workbooks');
  res.render('admin/workbook-form', { mode: 'edit', workbook, colors: WORKBOOK_COLORS, error: req.query.error || null });
});

router.post('/workbooks/:id', ensureAdmin, handleWorkbookUpload, (req, res) => {
  const workbook = db.prepare('SELECT * FROM workbooks WHERE id = ?').get(req.params.id);
  if (!workbook) return res.redirect('/admin/workbooks');

  if (req.uploadError) {
    return res.redirect(`/admin/workbooks/${req.params.id}/edit?error=` + encodeURIComponent(req.uploadError));
  }

  const { num, title, subtitle, icon, color, remove_file } = req.body;
  if (!title) {
    return res.redirect(`/admin/workbooks/${req.params.id}/edit?error=` + encodeURIComponent('제목은 필수입니다.'));
  }

  let filePath = workbook.file_path;
  if (req.file) {
    removeUploadedFile(workbook.file_path);
    filePath = `/uploads/files/${req.file.filename}`;
  } else if (remove_file) {
    removeUploadedFile(workbook.file_path);
    filePath = null;
  }

  db.prepare(
    `UPDATE workbooks SET num = ?, title = ?, subtitle = ?, icon = ?, color = ?, file_path = ? WHERE id = ?`
  ).run(num, title, subtitle || '', icon || 'file-earmark-text', color || 'cream', filePath, req.params.id);

  res.redirect('/admin/workbooks');
});

router.post('/workbooks/:id/delete', ensureAdmin, (req, res) => {
  const workbook = db.prepare('SELECT * FROM workbooks WHERE id = ?').get(req.params.id);
  if (workbook) {
    removeUploadedFile(workbook.file_path);
    db.prepare('DELETE FROM workbooks WHERE id = ?').run(req.params.id);
  }
  res.redirect('/admin/workbooks');
});

// =====================================================================
// 커뮤니티 게시글 (community_posts) — COMMUNITY 페이지
// =====================================================================
router.get('/community', ensureAdmin, (req, res) => {
  const posts = db.prepare('SELECT * FROM community_posts ORDER BY sort_order').all();
  res.render('admin/community', { posts });
});

router.get('/community/new', ensureAdmin, (req, res) => {
  res.render('admin/community-form', { mode: 'new', post: null, categories: COMMUNITY_CATEGORIES, error: req.query.error || null });
});

router.post('/community', ensureAdmin, (req, res) => {
  const { category, title, excerpt, post_date } = req.body;
  if (!category || !title) {
    return res.redirect('/admin/community/new?error=' + encodeURIComponent('카테고리와 제목은 필수입니다.'));
  }
  const maxOrder = db.prepare('SELECT MAX(sort_order) AS m FROM community_posts').get();
  const nextOrder = (maxOrder.m ?? -1) + 1;
  const date = post_date || new Date().toISOString().slice(0, 10);

  db.prepare(
    'INSERT INTO community_posts (category, title, excerpt, post_date, sort_order) VALUES (?, ?, ?, ?, ?)'
  ).run(category, title, excerpt || '', date, nextOrder);

  res.redirect('/admin/community');
});

router.get('/community/:id/edit', ensureAdmin, (req, res) => {
  const post = db.prepare('SELECT * FROM community_posts WHERE id = ?').get(req.params.id);
  if (!post) return res.redirect('/admin/community');
  res.render('admin/community-form', { mode: 'edit', post, categories: COMMUNITY_CATEGORIES, error: req.query.error || null });
});

router.post('/community/:id', ensureAdmin, (req, res) => {
  const { category, title, excerpt, post_date } = req.body;
  if (!category || !title) {
    return res.redirect(`/admin/community/${req.params.id}/edit?error=` + encodeURIComponent('카테고리와 제목은 필수입니다.'));
  }
  db.prepare(
    'UPDATE community_posts SET category = ?, title = ?, excerpt = ?, post_date = ? WHERE id = ?'
  ).run(category, title, excerpt || '', post_date, req.params.id);

  res.redirect('/admin/community');
});

router.post('/community/:id/delete', ensureAdmin, (req, res) => {
  db.prepare('DELETE FROM community_posts WHERE id = ?').run(req.params.id);
  res.redirect('/admin/community');
});

router.post('/community/:id/approve', ensureAdmin, (req, res) => {
  db.prepare(`UPDATE community_posts SET status = 'published' WHERE id = ?`).run(req.params.id);
  res.redirect('/admin/community');
});

// =====================================================================
// ABOUT 페이지 콘텐츠 관리
// =====================================================================
router.get('/about', ensureAdmin, (req, res) => {
  const heroPage = db.prepare("SELECT * FROM pages WHERE slug = 'about'").get();
  const missionPoints = db.prepare("SELECT * FROM features WHERE page = 'about-mission' ORDER BY sort_order").all();
  const values = db.prepare('SELECT * FROM values_list ORDER BY sort_order').all();
  const story = db.prepare('SELECT * FROM story_timeline ORDER BY sort_order').all();
  const repRow = db.prepare('SELECT * FROM representative LIMIT 1').get();
  const representative = repRow
    ? { ...repRow, bio: JSON.parse(repRow.bio || '[]'), credentials: JSON.parse(repRow.credentials || '[]') }
    : null;
  res.render('admin/about', {
    heroPage,
    missionPoints,
    values,
    story,
    representative,
    error: req.query.error || null,
  });
});

router.post('/about/hero', ensureAdmin, (req, res) => {
  const { title, subtitle, description } = req.body;
  db.prepare("UPDATE pages SET title = ?, subtitle = ?, description = ? WHERE slug = 'about'").run(
    title,
    subtitle,
    description
  );
  res.redirect('/admin/about');
});

// ---------- Our Mission ----------
router.post('/about/mission', ensureAdmin, (req, res) => {
  const { icon, title, description } = req.body;
  if (!title) return res.redirect('/admin/about?error=' + encodeURIComponent('제목은 필수입니다.'));
  const maxOrder = db.prepare("SELECT MAX(sort_order) AS m FROM features WHERE page = 'about-mission'").get();
  const nextOrder = (maxOrder.m ?? -1) + 1;
  db.prepare(
    "INSERT INTO features (page, icon, title, description, sort_order) VALUES ('about-mission', ?, ?, ?, ?)"
  ).run(icon || 'star', title, description || '', nextOrder);
  res.redirect('/admin/about');
});

router.post('/about/mission/:id', ensureAdmin, (req, res) => {
  const { icon, title, description } = req.body;
  db.prepare("UPDATE features SET icon = ?, title = ?, description = ? WHERE id = ? AND page = 'about-mission'").run(
    icon || 'star',
    title,
    description || '',
    req.params.id
  );
  res.redirect('/admin/about');
});

router.post('/about/mission/:id/delete', ensureAdmin, (req, res) => {
  db.prepare("DELETE FROM features WHERE id = ? AND page = 'about-mission'").run(req.params.id);
  res.redirect('/admin/about');
});

// ---------- Our Values ----------
router.post('/about/values', ensureAdmin, (req, res) => {
  const { num, title, description } = req.body;
  if (!title) return res.redirect('/admin/about?error=' + encodeURIComponent('제목은 필수입니다.'));
  const maxOrder = db.prepare('SELECT MAX(sort_order) AS m FROM values_list').get();
  const nextOrder = (maxOrder.m ?? -1) + 1;
  db.prepare('INSERT INTO values_list (num, title, description, sort_order) VALUES (?, ?, ?, ?)').run(
    num || String(nextOrder + 1).padStart(2, '0'),
    title,
    description || '',
    nextOrder
  );
  res.redirect('/admin/about');
});

router.post('/about/values/:id', ensureAdmin, (req, res) => {
  const { num, title, description } = req.body;
  db.prepare('UPDATE values_list SET num = ?, title = ?, description = ? WHERE id = ?').run(
    num,
    title,
    description || '',
    req.params.id
  );
  res.redirect('/admin/about');
});

router.post('/about/values/:id/delete', ensureAdmin, (req, res) => {
  db.prepare('DELETE FROM values_list WHERE id = ?').run(req.params.id);
  res.redirect('/admin/about');
});

// ---------- Our Story ----------
router.post('/about/story', ensureAdmin, (req, res) => {
  const { year, description } = req.body;
  if (!year) return res.redirect('/admin/about?error=' + encodeURIComponent('연도는 필수입니다.'));
  const maxOrder = db.prepare('SELECT MAX(sort_order) AS m FROM story_timeline').get();
  const nextOrder = (maxOrder.m ?? -1) + 1;
  db.prepare('INSERT INTO story_timeline (year, description, sort_order) VALUES (?, ?, ?)').run(
    year,
    description || '',
    nextOrder
  );
  res.redirect('/admin/about');
});

router.post('/about/story/:id', ensureAdmin, (req, res) => {
  const { year, description } = req.body;
  db.prepare('UPDATE story_timeline SET year = ?, description = ? WHERE id = ?').run(
    year,
    description || '',
    req.params.id
  );
  res.redirect('/admin/about');
});

router.post('/about/story/:id/delete', ensureAdmin, (req, res) => {
  db.prepare('DELETE FROM story_timeline WHERE id = ?').run(req.params.id);
  res.redirect('/admin/about');
});

// ---------- Representative ----------
router.post('/about/representative', ensureAdmin, handleRepPhotoUpload, (req, res) => {
  if (req.uploadError) {
    return res.redirect('/admin/about?error=' + encodeURIComponent(req.uploadError));
  }

  const { name, role, bio, quote, email, phone, remove_photo } = req.body;
  const bioLines = (bio || '')
    .split('\n')
    .map((l) => l.trim())
    .filter(Boolean);
  const existing = db.prepare('SELECT * FROM representative LIMIT 1').get();

  let photoPath = existing ? existing.photo_path : null;
  if (req.file) {
    removeUploadedFile(photoPath);
    photoPath = `/uploads/images/${req.file.filename}`;
  } else if (remove_photo) {
    removeUploadedFile(photoPath);
    photoPath = null;
  }

  if (existing) {
    db.prepare(
      'UPDATE representative SET name = ?, role = ?, bio = ?, quote = ?, email = ?, phone = ?, photo_path = ? WHERE id = ?'
    ).run(name, role, JSON.stringify(bioLines), quote, email, phone, photoPath, existing.id);
  } else {
    db.prepare(
      'INSERT INTO representative (name, role, bio, credentials, quote, email, phone, photo_path) VALUES (?, ?, ?, ?, ?, ?, ?, ?)'
    ).run(name, role, JSON.stringify(bioLines), JSON.stringify([]), quote, email, phone, photoPath);
  }
  res.redirect('/admin/about');
});

router.post('/about/representative/credentials', ensureAdmin, (req, res) => {
  const { icon, title, desc } = req.body;
  const rep = db.prepare('SELECT * FROM representative LIMIT 1').get();
  if (rep && title) {
    const credentials = JSON.parse(rep.credentials || '[]');
    credentials.push({ icon: icon || 'award', title, desc: desc || '' });
    db.prepare('UPDATE representative SET credentials = ? WHERE id = ?').run(JSON.stringify(credentials), rep.id);
  }
  res.redirect('/admin/about');
});

router.post('/about/representative/credentials/:index/delete', ensureAdmin, (req, res) => {
  const rep = db.prepare('SELECT * FROM representative LIMIT 1').get();
  if (rep) {
    const credentials = JSON.parse(rep.credentials || '[]');
    const idx = parseInt(req.params.index, 10);
    if (idx >= 0 && idx < credentials.length) {
      credentials.splice(idx, 1);
      db.prepare('UPDATE representative SET credentials = ? WHERE id = ?').run(JSON.stringify(credentials), rep.id);
    }
  }
  res.redirect('/admin/about');
});

module.exports = router;
