require('dotenv').config();
const express = require('express');
const path = require('path');
const session = require('express-session');
const db = require('./db/database');
const routes = require('./routes');
const adminRoutes = require('./routes/admin');
const consultationRoutes = require('./routes/consultations');
const diagnosticRoutes = require('./routes/diagnostics');

const app = express();
const PORT = process.env.PORT || 3000;

app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));

app.use(express.static(path.join(__dirname, 'public')));
app.use(express.urlencoded({ extended: true }));
app.use(express.json());

app.use(
  session({
    secret: process.env.SESSION_SECRET || 'life-design-company-admin-secret',
    resave: false,
    saveUninitialized: false,
    cookie: { maxAge: 1000 * 60 * 60 * 8 }, // 8시간
  })
);

app.use((req, res, next) => {
  res.locals.siteContact = db.prepare('SELECT name, email, phone FROM representative LIMIT 1').get() || null;
  next();
});

app.use('/admin', adminRoutes);
app.use('/consultations', consultationRoutes);
app.use('/lab/diagnostics', diagnosticRoutes);
app.use('/', routes);

app.use((req, res) => {
  res.status(404).render('404', {
    active: '',
    page: { title: '페이지를 찾을 수 없습니다', description: '요청하신 페이지를 찾을 수 없습니다.' },
  });
});

const server = app.listen(PORT, () => {
  console.log(`Life Design Company server running: http://localhost:${PORT}`);
});

// 느린 회선에서 큰 이미지/영상을 올릴 때 중간에 연결이 끊기지 않도록 타임아웃을 넉넉하게 잡는다.
server.requestTimeout = 10 * 60 * 1000; // 10분
server.headersTimeout = 10 * 60 * 1000 + 1000;
